import pandas as pd
import joblib
from pathlib import Path
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import numpy as np

ROOT = Path(__file__).parent
DATA_PATH = ROOT / "LengthOfStay_cleaned_250.csv"
MODEL_PATH = ROOT / "hospital_stay_model.joblib"

df = pd.read_csv(DATA_PATH)

TARGET = "lengthofstay"
# Exclude identifiers, dates, discharge date and post-target/derived columns
# to reduce leakage. eid is a row identifier; vdate/discharged are dates;
# outliers_capped and long_stay are preprocessing/target-derived indicators.
DROP = ["eid", "vdate", "discharged", "outliers_capped", "long_stay", TARGET]
X = df.drop(columns=[c for c in DROP if c in df.columns])
y = pd.to_numeric(df[TARGET], errors="coerce")

valid = y.notna()
X, y = X.loc[valid].copy(), y.loc[valid].copy()

categorical = X.select_dtypes(include=["object", "category"]).columns.tolist()
numeric = [c for c in X.columns if c not in categorical]

numeric_pipe = Pipeline([
    ("imputer", SimpleImputer(strategy="median"))
])
categorical_pipe = Pipeline([
    ("imputer", SimpleImputer(strategy="most_frequent")),
    ("onehot", OneHotEncoder(handle_unknown="ignore"))
])

preprocessor = ColumnTransformer([
    ("numeric", numeric_pipe, numeric),
    ("categorical", categorical_pipe, categorical)
])

pipeline = Pipeline([
    ("preprocessor", preprocessor),
    ("model", RandomForestRegressor(
        n_estimators=300,
        random_state=42,
        min_samples_leaf=2
    ))
])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)
pipeline.fit(X_train, y_train)
pred = pipeline.predict(X_test)

print(f"Rows used: {len(df)} | Features: {len(X.columns)}")
print(f"Test MAE:  {mean_absolute_error(y_test, pred):.3f} days")
print(f"Test RMSE: {np.sqrt(mean_squared_error(y_test, pred)):.3f} days")
print(f"Test R²:   {r2_score(y_test, pred):.3f}")
joblib.dump(pipeline, MODEL_PATH)
print(f"Saved model to {MODEL_PATH}")
print("Note: only 250 rows are available; metrics are unstable and not clinical validation.")