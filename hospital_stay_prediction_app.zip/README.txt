HOSPITAL STAY DURATION PREDICTION WEB APP

Files:
- LengthOfStay_cleaned_250.csv : your uploaded dataset copy
- train_model.py              : trains and evaluates the regression model
- app.py                      : Flask API + website server
- templates/index.html        : HTML/CSS/JavaScript user interface
- requirements.txt            : Python dependencies

RUN ON WINDOWS (VS Code terminal / Command Prompt)
1. Install Python 3.10+.
2. Open this folder in VS Code.
3. Create a virtual environment (recommended):
   py -m venv .venv
   .venv\Scripts\activate
4. Install packages:
   pip install -r requirements.txt
5. Train the model:
   python train_model.py
   Review MAE, RMSE and R² in the terminal.
6. Start the website:
   python app.py
7. Open http://127.0.0.1:5000 in your browser.

IMPORTANT DATASET NOTES
- Target: lengthofstay.
- Excluded: eid (identifier), vdate and discharged (dates), outliers_capped and long_stay (derived flags that can leak target information).
- Model features are the remaining columns, including rcount, gender, comorbidity flags, lab values, vital measurements, secondarydiagnosisnonicd9 and facid.
- Dataset has only 250 rows. A single 80/20 split gives a noisy evaluation; do not claim clinical accuracy from this sample.
- Inputs should be within plausible ranges observed in the dataset. This is an educational demo, not a medical device.
- For public deployment, disable debug mode, add input bounds/authentication, use HTTPS, protect patient data, and perform independent validation.