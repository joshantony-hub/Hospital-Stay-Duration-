from flask import Flask, request, jsonify, render_template
import joblib
import pandas as pd
from pathlib import Path

app = Flask(__name__)
MODEL_PATH = Path(__file__).parent / "hospital_stay_model.joblib"
model = joblib.load(MODEL_PATH)

FEATURES = [
    "rcount", "gender", "dialysisrenalendstage", "asthma", "irondef",
    "pneum", "substancedependence", "psychologicaldisordermajor",
    "depress", "psychother", "fibrosisandother", "malnutrition", "hemo",
    "hematocrit", "neutrophils", "sodium", "glucose", "bloodureanitro",
    "creatinine", "bmi", "pulse", "respiration", "secondarydiagnosisnonicd9",
    "facid"
]

@app.get("/")
def home():
    return render_template("index.html")

@app.post("/predict")
def predict():
    try:
        payload = request.get_json(force=True)
        row = {feature: payload.get(feature) for feature in FEATURES}
        frame = pd.DataFrame([row], columns=FEATURES)

        # Coerce numeric fields while preserving categorical columns.
        categorical = ["gender", "facid"]
        for col in FEATURES:
            if col not in categorical:
                frame[col] = pd.to_numeric(frame[col], errors="raise")

        if frame.isnull().any().any():
            return jsonify({"error": "Please complete all required fields."}), 400

        prediction = float(model.predict(frame)[0])
        prediction = max(0.0, prediction)
        return jsonify({
            "prediction_days": round(prediction, 2),
            "rounded_days": max(0, round(prediction)),
            "message": "Prediction from the trained dataset model; not for clinical decisions."
        })
    except (ValueError, TypeError) as exc:
        return jsonify({"error": f"Invalid input: {exc}"}), 400
    except Exception:
        app.logger.exception("Prediction failed")
        return jsonify({"error": "Prediction failed. Check the server logs."}), 500

if __name__ == "__main__":
    app.run(debug=True)